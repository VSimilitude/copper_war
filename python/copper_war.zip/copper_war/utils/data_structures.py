from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Alliance:
    alliance_id: str
    faction: str
    power: float
    starting_copper: int
    daily_copper_rate: int
    name: str | None = None
    server: str | None = None
    damage_weight: float | None = None


@dataclass
class EventConfig:
    attacker_faction: str
    day: str
    days_before: int


@dataclass
class GameState:
    current_copper: dict[str, int]
    brackets: dict[str, int]
    event_number: int
    day: str
    event_history: list[dict]
    alliances: list[Alliance]
    event_schedule: list[EventConfig] | None = None
    # Absolute season number of event_schedule[0]. event_number is always
    # absolute, so the schedule position of the current event is
    # event_number - start_event_number.
    start_event_number: int = 1
