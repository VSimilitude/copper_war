from __future__ import annotations

import csv
import io
import json
from importlib import resources

from copper_war.game.monte_carlo import MonteCarloResult
from copper_war.game.monte_carlo import aggregate_runs as aggregate_runs_impl
from copper_war.game.monte_carlo import run_monte_carlo as run_monte_carlo_impl
from copper_war.game.simulator import simulate_war
from copper_war.models.configurable import (
    DEFAULT_HEURISTIC_COEFFICIENTS,
    ConfigurableModel,
    heuristic_from_ratio,
)
from copper_war.utils.data_structures import Alliance, EventConfig
from copper_war.utils.validation import ValidationError, _check_model_references

_ALLOWED_MODEL_KEYS = {
    "random_seed",
    "battle_outcome_matrix",
    "event_targets",
    "event_reinforcements",
    "damage_weights",
    "targeting_strategy",
    "default_targets",
    "faction_targeting_strategy",
    "targeting_temperature",
    "power_noise",
    "outcome_noise",
    "tier_optimization_top_n",
    "tier_optimization_fallback",
    "heuristic_coefficients",
}

_HEURISTIC_COEFF_KEYS = {
    "full_slope", "full_intercept", "win_slope", "win_intercept",
}


def _validate_heuristic_coefficients(coeffs) -> None:
    if not isinstance(coeffs, dict):
        raise ValidationError("heuristic_coefficients must be an object")
    for day, params in coeffs.items():
        if day not in DEFAULT_HEURISTIC_COEFFICIENTS:
            raise ValidationError(
                f"heuristic_coefficients: unknown day '{day}' "
                f"(expected {sorted(DEFAULT_HEURISTIC_COEFFICIENTS)})"
            )
        if not isinstance(params, dict):
            raise ValidationError(
                f"heuristic_coefficients['{day}'] must be an object"
            )
        unknown = set(params) - _HEURISTIC_COEFF_KEYS
        if unknown:
            raise ValidationError(
                f"heuristic_coefficients['{day}']: unknown keys {sorted(unknown)} "
                f"(expected {sorted(_HEURISTIC_COEFF_KEYS)})"
            )
        for k, v in params.items():
            if not isinstance(v, (int, float)) or isinstance(v, bool):
                raise ValidationError(
                    f"heuristic_coefficients['{day}']['{k}'] must be a number"
                )


def _validate_state_structure(state_dict: dict) -> None:
    if not isinstance(state_dict, dict):
        raise ValidationError("State must be a JSON object")
    if "alliances" not in state_dict:
        raise ValidationError("State must contain 'alliances'")
    if "event_schedule" not in state_dict:
        raise ValidationError("State must contain 'event_schedule'")
    if not state_dict["alliances"]:
        raise ValidationError("State must contain at least one alliance")
    if not state_dict["event_schedule"]:
        raise ValidationError("State must contain at least one event")

    events_completed = state_dict.get("events_completed", 0)
    if not isinstance(events_completed, int) or isinstance(events_completed, bool) \
            or events_completed < 0:
        raise ValidationError(
            f"'events_completed' must be a non-negative integer, "
            f"got {events_completed!r}"
        )

    factions = {a["faction"] for a in state_dict["alliances"] if "faction" in a}
    if len(factions) != 2:
        raise ValidationError(
            f"State must contain exactly 2 factions, found {len(factions)}: "
            f"{sorted(factions)}"
        )

    for i, event in enumerate(state_dict["event_schedule"]):
        if "attacker_faction" in event and event["attacker_faction"] not in factions:
            raise ValidationError(
                f"Event #{i + 1}: attacker_faction '{event['attacker_faction']}' "
                f"is not one of the state's factions: {sorted(factions)}"
            )

    ids = [a.get("alliance_id") for a in state_dict["alliances"]]
    dupes = [aid for aid in ids if ids.count(aid) > 1]
    if dupes:
        raise ValidationError(
            f"Duplicate alliance_id(s): {sorted(set(dupes))}"
        )


def _events_completed(state_dict: dict) -> int:
    """Season events already resolved before this state (0 for a fresh
    season). event_schedule[0] is absolute event _events_completed() + 1, so
    event labels, per-event config keys, and week-based bracket narrowing stay
    anchored to absolute season numbers as the schedule shrinks."""
    return state_dict.get("events_completed", 0)


def _build_alliances(state_dict: dict) -> list[Alliance]:
    alliances = []
    for i, raw in enumerate(state_dict.get("alliances", [])):
        required = ["alliance_id", "faction", "power", "starting_copper", "daily_rate"]
        missing = [k for k in required if k not in raw]
        if missing:
            raise ValidationError(
                f"Alliance #{i + 1}: missing required fields: {missing}"
            )
        if raw["alliance_id"] == "*":
            raise ValidationError(
                f"Alliance #{i + 1}: '*' is reserved and cannot be used "
                f"as an alliance_id"
            )
        alliances.append(
            Alliance(
                alliance_id=raw["alliance_id"],
                faction=raw["faction"],
                power=raw["power"],
                starting_copper=raw["starting_copper"],
                daily_copper_rate=raw["daily_rate"],
                name=raw.get("name"),
                server=raw.get("server"),
            )
        )
    return alliances


def _build_schedule(state_dict: dict) -> list[EventConfig]:
    schedule = []
    for i, raw in enumerate(state_dict.get("event_schedule", [])):
        required = ["attacker_faction", "day", "days_before"]
        missing = [k for k in required if k not in raw]
        if missing:
            raise ValidationError(
                f"Event #{i + 1}: missing required fields: {missing}"
            )
        day = raw["day"].lower()
        if day not in ("wednesday", "saturday"):
            raise ValidationError(
                f"Event #{i + 1}: day must be 'wednesday' or 'saturday', "
                f"got '{raw['day']}'"
            )
        schedule.append(
            EventConfig(
                attacker_faction=raw["attacker_faction"],
                day=day,
                days_before=raw["days_before"],
            )
        )
    return schedule


def _validate_model_dict(model_dict: dict, alliances: list[Alliance]) -> None:
    if not isinstance(model_dict, dict):
        raise ValidationError("Model config must be a JSON object")

    unknown = set(model_dict.keys()) - _ALLOWED_MODEL_KEYS
    if unknown:
        raise ValidationError(f"Unknown model config keys: {sorted(unknown)}")

    if "heuristic_coefficients" in model_dict:
        _validate_heuristic_coefficients(model_dict["heuristic_coefficients"])

    alliance_ids = {a.alliance_id for a in alliances}
    faction_ids = {a.faction for a in alliances}
    _check_model_references(model_dict, alliance_ids, faction_ids)


def get_default_state() -> dict:
    """Return the bundled demo state for the web UI.

    Loaded from ``default_state.json`` packaged alongside this module so it
    rides along in ``copper_war.zip`` and is readable both under Pyodide and
    from the CLI. Replace that file to change the season's placeholder roster.
    """
    text = (
        resources.files(__package__)
        .joinpath("default_state.json")
        .read_text(encoding="utf-8")
    )
    return json.loads(text)


def get_default_model_config(state_dict: dict | None = None) -> dict:
    config: dict = {"random_seed": 42}

    if not state_dict:
        return config

    alliances = state_dict.get("alliances", [])
    events = state_dict.get("event_schedule", [])
    if not alliances or not events:
        return config

    # Find top alliance per faction by power
    top_by_faction: dict[str, str] = {}
    max_power: dict[str, int] = {}
    for a in alliances:
        faction = a.get("faction", "")
        power = a.get("power", 0)
        if faction not in max_power or power > max_power[faction]:
            max_power[faction] = power
            top_by_faction[faction] = a["alliance_id"]

    faction_list = list(top_by_faction.keys())
    if len(faction_list) != 2:
        return config

    top_a = top_by_faction[faction_list[0]]
    top_b = top_by_faction[faction_list[1]]

    # Build matrix for each unique day with empty probability objects
    days = list(dict.fromkeys(e.get("day", "") for e in events))
    matrix: dict = {}
    for day in days:
        matrix[day] = {
            top_a: {top_b: {}},
            top_b: {top_a: {}},
        }

    config["battle_outcome_matrix"] = matrix
    return config


def validate_state(state_dict: dict) -> dict:
    try:
        _validate_state_structure(state_dict)
        alliances = _build_alliances(state_dict)
        schedule = _build_schedule(state_dict)
        events_completed = _events_completed(state_dict)
        return {
            "ok": True,
            "events_completed": events_completed,
            "alliances": [
                {
                    "alliance_id": a.alliance_id,
                    "faction": a.faction,
                    "power": a.power,
                    "starting_copper": a.starting_copper,
                    "daily_rate": a.daily_copper_rate,
                }
                for a in alliances
            ],
            "event_schedule": [
                {
                    "event_number": events_completed + i + 1,
                    "attacker_faction": e.attacker_faction,
                    "day": e.day,
                    "days_before": e.days_before,
                }
                for i, e in enumerate(schedule)
            ],
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}


def validate_model_config(model_dict: dict, state_dict: dict) -> dict:
    try:
        alliances = _build_alliances(state_dict)
        _validate_model_dict(model_dict, alliances)
        return {"ok": True, "config": model_dict}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def run_single(
    state_dict: dict, model_dict: dict, seed: int | None = None
) -> dict:
    try:
        _validate_state_structure(state_dict)
        alliances = _build_alliances(state_dict)
        schedule = _build_schedule(state_dict)
        _validate_model_dict(model_dict, alliances)

        config = dict(model_dict)
        if seed is not None:
            config["random_seed"] = seed
        elif "random_seed" not in config:
            config["random_seed"] = 0

        model = ConfigurableModel(config, alliances)
        result = simulate_war(
            alliances, schedule, model,
            start_event_number=_events_completed(state_dict) + 1,
        )

        return {
            "ok": True,
            "seed": config["random_seed"],
            "final_copper": result["final_copper"],
            "rankings": result["rankings"],
            "event_history": result["event_history"],
        }
    except Exception as e:
        return {"ok": False, "error": str(e)}


def _mc_payload(result: MonteCarloResult) -> dict:
    return {
        "ok": True,
        "num_iterations": result.num_iterations,
        "base_seed": result.base_seed,
        "tier_distribution": {
            aid: {
                str(tier): frac
                for tier, frac in result.tier_distribution(aid).items()
            }
            for aid in result.tier_counts
        },
        "copper_stats": {
            aid: result.copper_stats(aid)
            for aid in result.tier_counts
        },
        "targeting_matrix": result.targeting_matrix(),
        "bracket_distribution": result.bracket_distribution(),
        "raw_results": result.per_iteration,
    }


def run_monte_carlo(
    state_dict: dict,
    model_dict: dict,
    num_iterations: int = 1000,
    base_seed: int = 0,
) -> dict:
    try:
        _validate_state_structure(state_dict)
        alliances = _build_alliances(state_dict)
        schedule = _build_schedule(state_dict)
        _validate_model_dict(model_dict, alliances)

        result = run_monte_carlo_impl(
            alliances, schedule, model_dict,
            num_iterations=num_iterations,
            base_seed=base_seed,
            start_event_number=_events_completed(state_dict) + 1,
        )
        return _mc_payload(result)
    except Exception as e:
        return {"ok": False, "error": str(e)}


def aggregate_runs(records: list) -> dict:
    """Re-aggregate Monte Carlo stats over a subset of per-iteration records."""
    try:
        if not records:
            raise ValidationError("No runs match the filter")
        return _mc_payload(aggregate_runs_impl(records))
    except Exception as e:
        return {"ok": False, "error": str(e)}


def compute_heuristic(
    attacker_power: float,
    defender_power: float,
    day: str,
    coefficients: dict | None = None,
) -> dict:
    """Compute heuristic battle probabilities for a power ratio and day.

    ``coefficients`` optionally overrides the per-day curve defaults (same
    structure as the ``heuristic_coefficients`` model-config key), so UI hints
    reflect a user's custom curve.
    """
    ratio = attacker_power / defender_power if defender_power > 0 else 0.0
    probs = heuristic_from_ratio(ratio, day, coefficients)
    full = round(probs["full_success"] * 100)
    partial = round(probs["partial_success"] * 100)
    return {"full": full, "partial": partial, "fail": max(0, 100 - full - partial)}


def get_heuristic_defaults() -> dict:
    """Return the built-in per-day heuristic coefficients (UI placeholders)."""
    return {day: dict(params) for day, params in DEFAULT_HEURISTIC_COEFFICIENTS.items()}


def import_csv(csv_text: str) -> dict:
    try:
        from copper_war.sheets.importer import import_from_csv

        reader = csv.reader(io.StringIO(csv_text))
        rows = list(reader)
        config = import_from_csv(rows)
        return {"ok": True, "config": config}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def generate_template_csv(state_dict: dict, top_n: int = 6) -> dict:
    try:
        from copper_war.sheets.template import generate_template

        alliances = _build_alliances(state_dict)
        schedule = _build_schedule(state_dict)
        rows = generate_template(
            alliances, schedule, top_n=top_n,
            events_completed=_events_completed(state_dict),
        )
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerows(rows)
        return {"ok": True, "csv": output.getvalue()}
    except Exception as e:
        return {"ok": False, "error": str(e)}
