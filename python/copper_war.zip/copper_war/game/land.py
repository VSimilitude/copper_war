"""City-pool model for production-rate uncertainty in Monte Carlo.

Season 4 / Copper War land model (see docs/game_mechanics.md and
scripts/estimate_city_ownership.py, whose inference this promotes into the
engine so it ships inside the Pyodide bundle):

  * Each alliance holds AT MOST 6 cities, each level 1-6, producing 100*level
    copper/hour. So an alliance's hourly rate / 100 is the sum of its held city
    levels (its "T").
  * Per server the cities are a fixed, scarce pool: 4 L6, 8 L5, 12 L4, 16 L3,
    20 L2, 24 L1 (84 cities, 22400/hr). The per-alliance cap of 3400/hr is just
    the best 6-city hand (4 L6 + 2 L5); only one alliance per server can reach
    it, and the caps/scarcity are what make some rate vectors *impossible*.

Production-rate noise works by (1) inferring a feasible base city assignment per
server from the current rates (exactly-6, power-weighted -- the tested heuristic
from estimate_city_ownership.py; it preserves each rate exactly), then (2) per
Monte-Carlo run, churning cities between alliances and the unowned pool via
random SWAPS. A swap keeps the server's full city multiset invariant, so every
sampled rate vector is realizable by construction -- no impossible outcomes:
automatically <=3400/hr per alliance, <=22400/hr per server, and jointly
packable into the 84-city pool. Intensity in [0,1] scales how many cities churn.
"""
from __future__ import annotations

import random
from collections import defaultdict

# Per-server city inventory (level -> count) and the derived constants.
SERVER_INVENTORY = {6: 4, 5: 8, 4: 12, 3: 16, 2: 20, 1: 24}
MAX_CITIES_PER_ALLIANCE = 6
CITY_UNIT = 100  # copper/hour per city level
PER_ALLIANCE_CAP = 100 * (4 * 6 + 2 * 5)  # 3400/hr
PER_SERVER_CAP = 100 * sum(lvl * n for lvl, n in SERVER_INVENTORY.items())  # 22400/hr


def candidates(T: int, max_spread: int) -> list[tuple[int, float, dict[int, int]]]:
    """All contiguous (no-gap) 6-city compositions summing to T, spread<=max_spread."""
    seen: dict[tuple, None] = {}
    for lo in range(1, 7):
        for length in range(1, max_spread + 2):
            hi = lo + length - 1
            if hi > 6:
                break
            levels = list(range(lo, hi + 1))

            def rec(i: int, cities_left: int, sum_left: int, cur: dict[int, int]) -> None:
                if i == len(levels) - 1:
                    if cities_left >= 1 and levels[i] * cities_left == sum_left:
                        seen[tuple(sorted({**cur, levels[i]: cities_left}.items()))] = None
                    return
                lvl = levels[i]
                for c in range(1, cities_left - (len(levels) - 1 - i) + 1):
                    if lvl * c > sum_left:
                        break
                    rec(i + 1, cities_left - c, sum_left - lvl * c, {**cur, lvl: c})

            rec(0, 6, T, {})
    out = []
    for key in seen:
        comp = dict(key)
        mean = T / 6
        spread = max(comp) - min(comp)
        imbalance = sum((lvl - mean) ** 2 * n for lvl, n in comp.items())
        out.append((spread, imbalance, comp))
    return out


def solve_server(members: list[dict], max_spread: int) -> dict[str, dict[int, int]] | None:
    """Branch-and-bound base assignment for one server, or None if caps can't be met.

    Each member dict needs "alliance_id", "T" (rate//100), and "power". Mirrors
    scripts/estimate_city_ownership.solve_server (the ground-truth-calibrated
    heuristic): strong alliances stay balanced, forced surplus high cities route
    to high power.
    """
    mem = sorted(members, key=lambda m: -m["power"])
    n = len(mem)
    rank_frac = [i / (n - 1) if n > 1 else 0.0 for i in range(n)]
    cand = []
    for idx, m in enumerate(mem):
        mean = m["T"] / 6
        scored = []
        for spread, imb, comp in candidates(m["T"], max_spread):
            high = comp.get(6, 0) * 2 + comp.get(5, 0)
            cost = (
                imb * (1 + 0.25 * mean)
                + (1.0 if spread >= 3 else 0.0)
                - 0.01 * high * (1 - rank_frac[idx])
            )
            scored.append((cost, comp))
        scored.sort(key=lambda x: x[0])
        if not scored:
            return None
        cand.append(scored)

    best: dict = {"cost": float("inf"), "pick": None}
    min_rem = [0.0] * (n + 1)
    for i in range(n - 1, -1, -1):
        min_rem[i] = min_rem[i + 1] + cand[i][0][0]

    def rec(i: int, rem: dict[int, int], picks: list, cost: float) -> None:
        if cost + min_rem[i] >= best["cost"]:
            return
        if i == n:
            best["cost"] = cost
            best["pick"] = list(picks)
            return
        for cst, comp in cand[i]:
            if cost + cst + min_rem[i + 1] >= best["cost"]:
                break
            if all(rem[lvl] >= cnt for lvl, cnt in comp.items()):
                for lvl, cnt in comp.items():
                    rem[lvl] -= cnt
                picks.append(comp)
                rec(i + 1, rem, picks, cost + cst)
                picks.pop()
                for lvl, cnt in comp.items():
                    rem[lvl] += cnt

    rec(0, dict(SERVER_INVENTORY), [], 0.0)
    if best["pick"] is None:
        return None
    return {m["alliance_id"]: comp for m, comp in zip(mem, best["pick"])}


def _expand(comp: dict[int, int]) -> list[int]:
    """{level: count} -> flat list of levels, e.g. {6:2, 5:1} -> [6, 6, 5]."""
    out: list[int] = []
    for lvl, cnt in comp.items():
        out.extend([lvl] * cnt)
    return out


def is_server_feasible(ts: list[int]) -> bool:
    """Can these per-alliance level-sums (T = rate//100) be packed into the
    server inventory with <=6 cities each? Independent checker used for tests /
    validation of sampled rate vectors."""
    ts = sorted(ts, reverse=True)
    all_ports = []
    for t in ts:
        ports = [dict(c) for _, _, c in candidates(t, 5)]  # spread up to 5 = any hand
        if not ports:
            return False
        all_ports.append(ports)
    inv = dict(SERVER_INVENTORY)

    def rec(i: int) -> bool:
        if i == len(all_ports):
            return True
        for comp in all_ports[i]:
            if all(inv[l] >= c for l, c in comp.items()):
                for l, c in comp.items():
                    inv[l] -= c
                if rec(i + 1):
                    return True
                for l, c in comp.items():
                    inv[l] += c
        return False

    return rec(0)


class LandNoiseModel:
    """Infers base city holdings once, then samples feasible perturbed rate
    vectors per Monte-Carlo run."""

    def __init__(self, alliances: list) -> None:
        self.base_rate = {a.alliance_id: a.hourly_copper_rate for a in alliances}
        # server -> {"aids": [...], "held": {aid: {level: count}}, "pool": {level: count}}
        self.servers: dict[str, dict] = {}
        self.skipped_servers: list[str] = []
        by_server: dict[str, list] = defaultdict(list)
        for a in alliances:
            by_server[a.server].append(a)
        for sv, members in by_server.items():
            info = self._infer_server(members)
            if info is None:
                if sv is not None:
                    self.skipped_servers.append(sv)
            else:
                self.servers[sv] = info

    def _infer_server(self, members: list) -> dict | None:
        recs = []
        for a in members:
            rate = a.hourly_copper_rate
            if a.server is None or rate % CITY_UNIT != 0:
                return None  # can't decompose onto the 100/hr city grid
            recs.append(
                {"alliance_id": a.alliance_id, "T": rate // CITY_UNIT, "power": a.power}
            )
        for max_spread in (2, 3):
            res = solve_server(recs, max_spread)
            if res is not None:
                held = {aid: dict(comp) for aid, comp in res.items()}
                pool = dict(SERVER_INVENTORY)
                for comp in held.values():
                    for lvl, cnt in comp.items():
                        pool[lvl] -= cnt
                return {"aids": [r["alliance_id"] for r in recs], "held": held, "pool": pool}
        return None

    def sample_rates(self, intensity: float, rng: random.Random) -> dict[str, int]:
        """Return {alliance_id: hourly_rate} for one run. Alliances on
        unmodelable servers keep their base rate."""
        rates = dict(self.base_rate)
        if intensity <= 0:
            return rates
        for info in self.servers.values():
            aids = info["aids"]
            held = {aid: _expand(info["held"][aid]) for aid in aids}
            pool = _expand(info["pool"])
            total_cities = sum(len(v) for v in held.values())
            k = round(intensity * total_cities)
            for _ in range(k):
                movers = [x for x in aids if held[x]]
                if not movers:
                    break
                a = rng.choice(movers)
                # Counterparty: another alliance holding >=1 city, or the pool.
                counters = [x for x in aids if x != a and held[x]]
                if pool:
                    counters.append("__pool__")
                if not counters:
                    continue
                c = rng.choice(counters)
                a_cities = held[a]
                c_cities = pool if c == "__pool__" else held[c]
                i = rng.randrange(len(a_cities))
                j = rng.randrange(len(c_cities))
                # Swap one city each way -> counts invariant, full server
                # multiset invariant, so the result is always feasible.
                a_cities[i], c_cities[j] = c_cities[j], a_cities[i]
            for aid in aids:
                rates[aid] = CITY_UNIT * sum(held[aid])
        return rates
