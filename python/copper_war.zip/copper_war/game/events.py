from __future__ import annotations

from collections import defaultdict

from copper_war.game.battle import resolve_battle
from copper_war.game.mechanics import (
    SECONDARY_COUNT,
    assign_brackets,
    calculate_theft_percentage,
)
from copper_war.models.base import BattleModel
from copper_war.utils.data_structures import Alliance, GameState


def coordinate_battle(
    attackers: list[Alliance],
    defenders: list[Alliance],
    current_state: GameState,
    day: str,
    model: BattleModel,
) -> tuple[dict[str, int], dict]:
    primary_defender = defenders[0]

    outcome, probabilities = model.determine_battle_outcome(
        current_state, attackers, defenders, day
    )

    splits = model.determine_damage_splits(
        current_state, attackers, primary_defender
    )

    custom_theft_pct = probabilities.get("custom_theft_percentage")

    transfers = resolve_battle(
        attackers=[a.alliance_id for a in attackers],
        primary_defender=primary_defender.alliance_id,
        outcome_level=outcome,
        damage_splits=splits,
        current_copper=current_state.current_copper,
        custom_theft_percentage=custom_theft_pct,
    )

    theft_pct = calculate_theft_percentage(outcome, custom_theft_pct)

    battle_info = {
        "attackers": [a.alliance_id for a in attackers],
        "defenders": [primary_defender.alliance_id],
        "reinforcements": [d.alliance_id for d in defenders[1:]],
        "outcome": outcome,
        "outcome_probabilities": probabilities,
        "defender_buildings": SECONDARY_COUNT,
        "theft_percentage": theft_pct,
        "damage_splits": splits,
        "transfers": transfers,
    }

    return transfers, battle_info


def coordinate_event(
    current_state: GameState,
    attacker_faction: str,
    day: str,
    event_number: int,
    model: BattleModel,
    settle_copper: dict[str, int] | None = None,
) -> tuple[dict[str, int], dict]:
    # Bracketing, targeting, and loot are all sized off ``current_state.current_copper``
    # (the lock-time snapshot). ``settle_copper`` is the balance the resulting
    # transfers are applied to — the battle-time copper, which carries the income
    # accrued between lock and battle. Defaults to the lock-time copper so callers
    # that don't model the lock offset (e.g. unit tests) behave as before.
    alliances = current_state.alliances
    factions = {a.faction for a in alliances}
    defender_faction = [f for f in factions if f != attacker_faction][0]

    attacker_brackets = assign_brackets(
        alliances, attacker_faction, current_state.current_copper, event_number
    )
    defender_brackets = assign_brackets(
        alliances, defender_faction, current_state.current_copper, event_number
    )

    all_brackets = {**attacker_brackets, **defender_brackets}
    current_state.brackets = all_brackets

    alliance_map = {a.alliance_id: a for a in alliances}
    bracket_numbers = sorted(set(attacker_brackets.values()))

    total_transfers: dict[str, int] = defaultdict(int)
    all_battles = []
    all_targeting = {}
    all_reinforcements = {}
    bracket_info = {}

    for bracket_num in bracket_numbers:
        bracket_attackers = [
            alliance_map[aid]
            for aid, b in attacker_brackets.items()
            if b == bracket_num
        ]
        bracket_defenders = [
            alliance_map[aid]
            for aid, b in defender_brackets.items()
            if b == bracket_num
        ]

        if not bracket_attackers or not bracket_defenders:
            continue

        targets = model.generate_targets(
            current_state, bracket_attackers, bracket_defenders, bracket_num
        )
        all_targeting.update(targets)

        reinforcements = model.generate_reinforcements(
            current_state, targets, bracket_defenders, bracket_num
        )
        all_reinforcements.update(reinforcements)

        bracket_info[str(bracket_num)] = {
            "attackers": [a.alliance_id for a in bracket_attackers],
            "defenders": [d.alliance_id for d in bracket_defenders],
        }

        # Group battles: attackers targeting same defender
        battles_by_defender: dict[str, list[str]] = defaultdict(list)
        for attacker_id, defender_id in targets.items():
            battles_by_defender[defender_id].append(attacker_id)

        for primary_defender_id, attacker_ids in battles_by_defender.items():
            battle_attackers = [alliance_map[aid] for aid in attacker_ids]
            battle_defenders = [alliance_map[primary_defender_id]]

            # Add reinforcements
            for reinf_id, target_id in reinforcements.items():
                if target_id == primary_defender_id:
                    battle_defenders.append(alliance_map[reinf_id])

            transfers, battle_info = coordinate_battle(
                battle_attackers, battle_defenders, current_state, day, model
            )

            for aid, amount in transfers.items():
                total_transfers[aid] += amount

            all_battles.append(battle_info)

    # Apply transfers to the settle balance (battle-time copper); the loot
    # amounts were already sized off the lock-time copper inside resolve_battle.
    settle = settle_copper if settle_copper is not None else current_state.current_copper
    updated_copper = dict(settle)
    for aid, amount in total_transfers.items():
        updated_copper[aid] += amount

    event_info = {
        "event_number": event_number,
        "attacker_faction": attacker_faction,
        "day": day,
        "brackets": bracket_info,
        "targeting": all_targeting,
        "reinforcements": all_reinforcements,
        "battles": all_battles,
    }

    return updated_copper, event_info
