from __future__ import annotations

from copper_war.game.events import coordinate_event
from copper_war.game.mechanics import BRACKET_LOCK_HOURS, calculate_final_rankings
from copper_war.models.base import BattleModel
from copper_war.utils.data_structures import Alliance, EventConfig, GameState


def process_between_events(
    current_copper: dict[str, int],
    hours_elapsed: int,
    hourly_rates: dict[str, int],
) -> dict[str, int]:
    updated = dict(current_copper)
    for aid, rate in hourly_rates.items():
        updated[aid] += rate * hours_elapsed
    return updated


def simulate_war(
    alliances: list[Alliance],
    event_schedule: list[EventConfig],
    model: BattleModel,
    start_event_number: int = 1,
) -> dict:
    # start_event_number anchors absolute event numbers for mid-season runs
    # (a state file with events_completed > 0, or the maximize_tier forward
    # sim), so week-dependent mechanics like bracket narrowing resolve to the
    # correct week and per-event config keys stay stable across the season.
    current_copper = {a.alliance_id: a.starting_copper for a in alliances}
    hourly_rates = {a.alliance_id: a.hourly_copper_rate for a in alliances}
    event_history = []

    for event_number, event_config in enumerate(event_schedule, start=start_event_number):
        # Two copper snapshots are derived from the post-previous-battle balance:
        #   bracket_copper — copper at declaration/bracket lock, BRACKET_LOCK_HOURS
        #     before the battle. Drives bracket assignment, targeting, and the
        #     loot base (you can only steal a cut of what the defender held when
        #     the matchup locked, not the income they accrued afterward).
        #   battle_copper — copper at battle time (full passive income). This is
        #     the running balance the loot is settled against, so defenders keep
        #     every day of income and only lose loot sized off bracket_copper.
        # days_before encodes 11:00->11:00 spans in whole days; convert to hours
        # to settle against the hourly production rates.
        battle_hours = event_config.days_before * 24
        lock_hours = max(0, battle_hours - BRACKET_LOCK_HOURS)
        bracket_copper = {
            aid: round(v)
            for aid, v in process_between_events(
                current_copper, lock_hours, hourly_rates
            ).items()
        }
        battle_copper = process_between_events(
            current_copper, battle_hours, hourly_rates
        )

        state = GameState(
            current_copper=bracket_copper,
            brackets={},
            event_number=event_number,
            day=event_config.day,
            event_history=event_history,
            alliances=alliances,
            event_schedule=event_schedule,
            start_event_number=start_event_number,
        )

        if hasattr(model, "set_effective_powers"):
            model.set_effective_powers()

        updated_copper, event_info = coordinate_event(
            state,
            event_config.attacker_faction,
            event_config.day,
            event_number,
            model,
            settle_copper=battle_copper,
        )

        current_copper = updated_copper
        event_info["days_before"] = event_config.days_before
        # Pre-battle display = lock-time copper (what bracketing and the steal
        # are based on); post-battle = battle-time copper +/- the loot.
        event_info["copper_before"] = bracket_copper
        event_info["copper_after"] = dict(current_copper)
        event_history.append(event_info)

    rankings = calculate_final_rankings(alliances, current_copper)

    return {
        "final_copper": current_copper,
        "rankings": rankings,
        "event_history": event_history,
    }
