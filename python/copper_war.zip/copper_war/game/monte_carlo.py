from __future__ import annotations

import statistics
from collections import Counter
from dataclasses import dataclass, field

from copper_war.game.simulator import simulate_war
from copper_war.models.configurable import ConfigurableModel
from copper_war.utils.data_structures import Alliance, EventConfig


@dataclass
class MonteCarloResult:
    num_iterations: int
    base_seed: int
    tier_counts: dict[str, Counter[int]] = field(default_factory=dict)
    copper_totals: dict[str, list[int]] = field(default_factory=dict)
    per_iteration: list[dict] = field(default_factory=list)
    targeting_counts: dict[str, dict[str, Counter[str]]] = field(default_factory=dict)
    # bracket_counts[event_str][alliance_id][bucket] = count, where bucket is
    # "1".."4" or "5+" (the declaration-group number, collapsed past 5).
    bracket_counts: dict[str, dict[str, Counter[str]]] = field(default_factory=dict)

    def tier_distribution(self, alliance_id: str) -> dict[int, float]:
        counts = self.tier_counts[alliance_id]
        return {tier: counts[tier] / self.num_iterations for tier in range(1, 6)}

    def copper_stats(self, alliance_id: str) -> dict[str, int]:
        values = sorted(self.copper_totals[alliance_id])
        n = len(values)
        return {
            "mean": round(statistics.mean(values)),
            "median": round(statistics.median(values)),
            "min": values[0],
            "max": values[-1],
            "p25": values[n // 4],
            "p75": values[3 * n // 4],
        }

    def rank_summary(self) -> dict[str, dict[int, float]]:
        return {aid: self.tier_distribution(aid) for aid in self.tier_counts}

    def targeting_matrix(self) -> dict[str, dict[str, dict[str, float]]]:
        matrix = {}
        for event_num, attackers in self.targeting_counts.items():
            matrix[event_num] = {}
            for attacker_id, defender_counts in attackers.items():
                matrix[event_num][attacker_id] = {
                    def_id: count / self.num_iterations
                    for def_id, count in defender_counts.items()
                }
        return matrix

    def most_likely_tier(self, alliance_id: str) -> int:
        counts = self.tier_counts[alliance_id]
        return max(range(1, 6), key=lambda t: counts[t])

    def bracket_distribution(self) -> dict[str, dict[str, dict[str, float]]]:
        """{event_str: {alliance_id: {bucket: fraction}}} over 1..4, 5+."""
        buckets = ("1", "2", "3", "4", "5+")
        out: dict[str, dict[str, dict[str, float]]] = {}
        for event_str, per_aid in self.bracket_counts.items():
            out[event_str] = {
                aid: {b: counts[b] / self.num_iterations for b in buckets}
                for aid, counts in per_aid.items()
            }
        return out


def _bracket_bucket(bracket_num: int) -> str:
    return "5+" if bracket_num >= 5 else str(bracket_num)


def aggregate_runs(records: list[dict], base_seed: int = 0) -> MonteCarloResult:
    """Build aggregate statistics from per-iteration records.

    Accepts the dicts stored in ``MonteCarloResult.per_iteration`` (or their
    JSON round-tripped equivalents), so a filtered subset of runs can be
    re-aggregated with the same logic as a full run.
    """
    result = MonteCarloResult(num_iterations=len(records), base_seed=base_seed)
    if not records:
        return result

    alliance_ids = list(records[0]["rankings"])
    for aid in alliance_ids:
        result.tier_counts[aid] = Counter()
        result.copper_totals[aid] = []

    for rec in records:
        for event_num, targeting in rec.get("targeting", {}).items():
            ev_targets = result.targeting_counts.setdefault(event_num, {})
            for attacker_id, defender_id in targeting.items():
                ev_targets.setdefault(attacker_id, Counter())[defender_id] += 1

        for event_num, per_aid in rec.get("brackets", {}).items():
            ev_brackets = result.bracket_counts.setdefault(event_num, {})
            for aid, bnum in per_aid.items():
                ev_brackets.setdefault(aid, Counter())[_bracket_bucket(int(bnum))] += 1

        for aid in alliance_ids:
            result.copper_totals[aid].append(rec["final_copper"][aid])
            result.tier_counts[aid][rec["rankings"][aid]] += 1

    result.per_iteration = list(records)
    return result


def run_monte_carlo(
    alliances: list[Alliance],
    event_schedule: list[EventConfig],
    model_config: dict,
    num_iterations: int,
    base_seed: int = 0,
    start_event_number: int = 1,
) -> MonteCarloResult:
    records: list[dict] = []
    for i in range(num_iterations):
        seed = base_seed + i
        iter_config = dict(model_config)
        iter_config["random_seed"] = seed

        model = ConfigurableModel(iter_config, alliances)
        war_result = simulate_war(
            alliances, event_schedule, model,
            start_event_number=start_event_number,
        )

        iter_brackets: dict[str, dict[str, int]] = {}
        iter_targeting: dict[str, dict[str, str]] = {}
        for event in war_result["event_history"]:
            event_num = str(event["event_number"])
            iter_targeting[event_num] = dict(event["targeting"])
            ev_iter = iter_brackets.setdefault(event_num, {})
            for bnum_str, group in event.get("brackets", {}).items():
                bnum = int(bnum_str)
                for a in group.get("attackers", []) + group.get("defenders", []):
                    ev_iter[a] = bnum

        records.append({
            "seed": seed,
            "final_copper": dict(war_result["final_copper"]),
            "rankings": dict(war_result["rankings"]),
            "brackets": iter_brackets,
            "targeting": iter_targeting,
        })

    return aggregate_runs(records, base_seed=base_seed)
