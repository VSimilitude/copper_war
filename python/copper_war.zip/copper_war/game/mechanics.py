from __future__ import annotations


# Season 4 (Copper War) plunder structure. Unlike S3, the building layout is
# fixed and does NOT vary with the defender's copper: every alliance defends one
# Alliance Center plus three secondary warehouses (Stone / Oil / Magatama), all
# unlocked by the start of Copper War.
ALLIANCE_CENTER_PCT = 6.0   # copper looted when the Alliance Center is destroyed
SECONDARY_PCT = 3.0         # copper looted per secondary warehouse destroyed
SECONDARY_COUNT = 3         # fixed number of secondary warehouses
MAX_THEFT_PCT = ALLIANCE_CENTER_PCT + SECONDARY_COUNT * SECONDARY_PCT  # 15.0


# How long before the battle's state snapshot the bracket/declaration lock sits.
# Brackets, declarations (targeting), and the loot base are all anchored to the
# copper held at lock time; only the running balance accrues the final stretch of
# passive income, which defenders keep (loot is sized off lock-time copper, not
# battle-time copper). The lock fires at 22:00 and state snapshots are read at
# 11:00, which is 1.5 days + 1 hour = 37 h before the snapshot (days_before
# encodes 11:00->11:00 spans). Copper appears to be captured just *before* the
# 22:00 income tick, so the effective offset is one tick earlier: 38 h (1.5 days
# + 2 h).
#
# Calibrated against Event 3 (2026-06-17): the best-fit offset is 38.0 h, where
# loot lands on a clean 15%/9% of lock-time copper (mean abs error 0.026%), vs
# ~13.8%/8.3% of battle-time copper. The 37h-vs-38h gap is within leaderboard
# rounding noise on one event; revisit if a later event disagrees. See
# simulate_war for how the two snapshots are derived. Expressed directly in hours
# now that production rates are hourly (previously 38/24 days).
BRACKET_LOCK_HOURS = 38


def calculate_theft_percentage(
    outcome_level: str,
    custom_theft_percentage: float | None = None,
) -> float:
    if outcome_level == "custom":
        return custom_theft_percentage
    if outcome_level == "full_success":
        # AC + all secondaries destroyed → 6 + 3×3 = 15%
        return ALLIANCE_CENTER_PCT + SECONDARY_COUNT * SECONDARY_PCT
    elif outcome_level == "partial_success":
        # secondaries only, AC survives → 3×3 = 9%
        return SECONDARY_COUNT * SECONDARY_PCT
    else:  # fail
        return 0.0


# Season 4 declaration-group narrowing. Alliances may only declare on enemies in
# their own group (by within-faction copper rank), and the groups shrink each
# Copper War week, forcing closer matchups over time:
#   week 1 → size 10 (1-10, 11-20, 21-30)
#   week 2 → size 6  (1-6, 7-12, 13-18, 19-24, 25-30)
#   weeks 3-4 → size 3 (1-3, 4-6, ..., 28-30)
# We model the top 30 ranks only; ranks 31+ collapse into a single tail group
# (out of scope for matchup fidelity, but kept so full rosters still simulate).
EVENTS_PER_WEEK = 2
_BRACKET_SIZE_BY_WEEK = {1: 10, 2: 6, 3: 3, 4: 3}
_DEFAULT_BRACKET_SIZE = 3  # weeks beyond the standard 4 stay fully narrowed
TOP_RANK_MODELED = 30
TAIL_BRACKET = 9999


def week_for_event(event_number: int) -> int:
    """Map an absolute event number (1-based) to its Copper War week."""
    return (event_number - 1) // EVENTS_PER_WEEK + 1


def bracket_size_for_event(event_number: int) -> int:
    return _BRACKET_SIZE_BY_WEEK.get(week_for_event(event_number), _DEFAULT_BRACKET_SIZE)


def assign_brackets(
    alliances: list,
    faction: str,
    current_copper: dict[str, int],
    event_number: int = 1,
) -> dict[str, int]:
    faction_alliances = [a for a in alliances if a.faction == faction]
    sorted_alliances = sorted(
        faction_alliances, key=lambda a: current_copper[a.alliance_id], reverse=True
    )
    size = bracket_size_for_event(event_number)
    brackets = {}
    for rank_zero, alliance in enumerate(sorted_alliances):
        if rank_zero >= TOP_RANK_MODELED:
            brackets[alliance.alliance_id] = TAIL_BRACKET
        else:
            brackets[alliance.alliance_id] = rank_zero // size + 1
    return brackets


def calculate_final_rankings(
    alliances: list, current_copper: dict[str, int]
) -> dict[str, int]:
    sorted_alliances = sorted(
        alliances, key=lambda a: current_copper[a.alliance_id], reverse=True
    )
    rankings = {}
    for rank_zero, alliance in enumerate(sorted_alliances):
        rank = rank_zero + 1
        if rank == 1:
            tier = 1
        elif rank <= 3:
            tier = 2
        elif rank <= 10:
            tier = 3
        elif rank <= 20:
            tier = 4
        else:
            tier = 5
        rankings[alliance.alliance_id] = tier
    return rankings
